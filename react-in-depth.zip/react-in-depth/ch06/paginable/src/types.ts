export interface Employee {
  name: string;
  title: string;
}

export interface Entry {
  name: string;
  points: number;
}
