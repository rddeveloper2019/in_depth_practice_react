export default function App() {
  return (
    <main>
      <h1>Vite Example with JS</h1>
    </main>
  );
}
