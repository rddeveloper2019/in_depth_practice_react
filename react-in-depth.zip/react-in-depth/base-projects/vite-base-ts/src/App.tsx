export default function App() {
  return (
    <main>
      <h1>Vite Example with TS</h1>
    </main>
  );
}
