import { createContext } from "use-context-selector";

export const DataContext = createContext({ state: {}, actions: {} });
